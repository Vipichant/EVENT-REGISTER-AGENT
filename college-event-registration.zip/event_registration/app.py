from flask import Flask, send_from_directory, redirect, url_for
from flask_login import LoginManager
from config import Config
from models import db, Admin
import os

def create_app():
    """
    Flask Application Factory. Configures and launches our Python Server.
    """
    app = Flask(__name__, static_folder='static', template_folder='templates')
    
    # Load Configuration from config.py
    app.config.from_object(Config)

    # Initialize SQLAlchemy Engine
    db.init_app(app)

    # Initialize Login Manager for session safety
    login_manager = LoginManager()
    login_manager.login_view = 'main.admin_login'
    login_manager.login_message_category = 'warning'
    login_manager.init_app(app)

    @login_manager.user_loader
    def load_user(user_id):
        return Admin.query.get(int(user_id))

    # Register Routes Blueprints
    from routes import main_bp
    app.register_blueprint(main_bp)

    # Serve static uploaded files (photos and screenshots) locally
    @app.route('/uploads/<path:filename>')
    def serve_uploads(filename):
        return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

    # Create directories, initialize tables, and seed admin
    with app.app_context():
        # Create directories if missing
        os.makedirs(app.config['STUDENT_UPLOAD_SUBFOLDER'], exist_ok=True)
        os.makedirs(app.config['PAYMENT_UPLOAD_SUBFOLDER'], exist_ok=True)
        
        # Create all tables (SQLite/MySQL)
        db.create_all()

        # Seed default Admin account (admin / admin123)
        default_admin = Admin.query.filter_by(username='admin').first()
        if not default_admin:
            default_admin = Admin(username='admin')
            default_admin.set_password('admin123')
            db.session.add(default_admin)
            db.session.commit()
            print("[+] Seeded Admin credentials: admin / admin123")

    return app

if __name__ == '__main__':
    # Launch local development server on port 5000
    app = create_app()
    app.run(host='0.0.0.0', port=5000, debug=True)
