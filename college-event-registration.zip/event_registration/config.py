import os

class Config:
    # Secret key for CSRF protection in Flask-WTF and sessions
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'apex-super-secret-symposium-key-2026'
    
    # Database Configuration (Defaults to local SQLite for easy local setup, can be configured for MySQL)
    # MySQL string: 'mysql+pymysql://username:password@localhost/event_registration_db'
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///event_registration_db.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # File upload configurations
    UPLOAD_FOLDER = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'uploads')
    STUDENT_UPLOAD_SUBFOLDER = os.path.join(UPLOAD_FOLDER, 'students')
    PAYMENT_UPLOAD_SUBFOLDER = os.path.join(UPLOAD_FOLDER, 'payments')
    
    # 10 MB maximum request size limit for safety
    MAX_CONTENT_LENGTH = 10 * 1024 * 1024 
    
    # Allowed file formats
    ALLOWED_PHOTO_EXTENSIONS = {'.jpg', '.jpeg', '.png'}
    ALLOWED_SCREENSHOT_EXTENSIONS = {'.jpg', '.jpeg', '.png', '.pdf'}
