-- ======================================================
-- DATABASE CREATION SCRIPT FOR EVENT REGISTRATION SYSTEM
-- Target: MySQL / MariaDB Server
-- ======================================================

CREATE DATABASE IF NOT EXISTS event_registration_db;
USE event_registration_db;

-- 1. Table for Student Registrations
CREATE TABLE IF NOT EXISTS registrations (
    registration_id INT PRIMARY KEY AUTO_INCREMENT,
    student_name VARCHAR(100) NOT NULL,
    student_photo VARCHAR(255) NOT NULL, -- Stores relative path to uploaded photo
    year VARCHAR(20) NOT NULL,
    department VARCHAR(100) NOT NULL,
    college_name VARCHAR(150) NOT NULL,
    register_number VARCHAR(50) UNIQUE NOT NULL, -- Ensure unique register ids
    mobile_number VARCHAR(15) NOT NULL,
    email VARCHAR(100) NOT NULL,
    event_name VARCHAR(100) NOT NULL,
    amount_paid DECIMAL(10,2) NOT NULL, -- Stores fractional money values safely
    payment_method VARCHAR(50) NOT NULL,
    transaction_id VARCHAR(100) NOT NULL,
    payment_screenshot VARCHAR(255) NOT NULL, -- Stores relative path to payment invoice
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. Table for Admin Accounts
CREATE TABLE IF NOT EXISTS admins (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Initial Admin Seed Data
-- Default credentials are: admin / admin123
-- Password hash generated using Werkzeug'spbkdf2_sha256 algorithm
INSERT INTO admins (username, password_hash)
VALUES ('admin', 'scrypt:32768:8:1$pG7A74N0Gof41kU4$df6e9df52c7980ff636ee009eaeb949cefc946bf8e29a99684b39b03f0b83f3da332f790bc778b868e4a9e557b7f16ef06e12727651a7071db8c11e74f260381')
ON DUPLICATE KEY UPDATE username=username;
