from flask_wtf import FlaskForm
from wtforms import StringField, SelectField, DecimalField, BooleanField, PasswordField
from flask_wtf.file import FileField, FileRequired, FileAllowed
from wtforms.validators import DataRequired, Email, Length, ValidationError
import re

# Choices
YEAR_CHOICES = [
    ('', 'Select Academic Year'),
    ('1st Year', '1st Year'),
    ('2nd Year', '2nd Year'),
    ('3rd Year', '3rd Year'),
    ('4th Year', '4th Year'),
    ('Post Graduate', 'Post Graduate')
]

DEPT_CHOICES = [
    ('', 'Select Department'),
    ('Computer Science & Engineering (CSE)', 'Computer Science & Engineering (CSE)'),
    ('Information Technology (IT)', 'Information Technology (IT)'),
    ('Electronics & Communication Engineering (ECE)', 'Electronics & Communication Engineering (ECE)'),
    ('Electrical & Electronics Engineering (EEE)', 'Electrical & Electronics Engineering (EEE)'),
    ('Mechanical Engineering (MECH)', 'Mechanical Engineering (MECH)'),
    ('Civil Engineering (CIVIL)', 'Civil Engineering (CIVIL)'),
    ('Artificial Intelligence & Data Science (AI&DS)', 'Artificial Intelligence & Data Science (AI&DS)')
]

EVENT_CHOICES = [
    ('', 'Select Technical Event'),
    ('WebCraft (Web Design & Development)', 'WebCraft (Web Design & Development) - $150'),
    ('CodeForge (Speed Competitive Coding)', 'CodeForge (Speed Competitive Coding) - $200'),
    ('TechQuiz (General & IT Quiz)', 'TechQuiz (General & IT Quiz) - $100'),
    ('Paper Presentation (Research Paper)', 'Paper Presentation (Research Paper) - $250'),
    ('UI/UX Odyssey (Interface Design)', 'UI/UX Odyssey (Interface Design) - $150'),
    ('RoboWars (Sumo Robotics)', 'RoboWars (Sumo Robotics) - $300')
]

PAYMENT_CHOICES = [
    ('', 'Select Payment Method'),
    ('UPI', 'UPI'),
    ('Credit Card', 'Credit Card'),
    ('Debit Card', 'Debit Card'),
    ('Net Banking', 'Net Banking'),
    ('Cash', 'Cash')
]


class RegistrationForm(FlaskForm):
    """
    Form class representing student event registration with comprehensive field-by-field validations.
    """
    student_name = StringField('Student Name', validators=[
        DataRequired(message='Student Name is required.'),
        Length(min=2, max=100, message='Name must be between 2 and 100 characters.')
    ])
    
    student_photo = FileField('Student Photo', validators=[
        FileRequired(message='Student Portrait Photo is required.'),
        FileAllowed(['jpg', 'jpeg', 'png'], message='Student Portrait must be in JPG, JPEG, or PNG format.')
    ])
    
    year = SelectField('Academic Year', choices=YEAR_CHOICES, validators=[
        DataRequired(message='Please select your academic year.')
    ])
    
    department = SelectField('Department', choices=DEPT_CHOICES, validators=[
        DataRequired(message='Please select your department.')
    ])
    
    college_name = StringField('College Name', validators=[
        DataRequired(message='College Name is required.'),
        Length(max=150, message='College Name must not exceed 150 characters.')
    ])
    
    register_number = StringField('Register Number', validators=[
        DataRequired(message='A unique Register/Roll Number is required.'),
        Length(max=50, message='Register number must not exceed 50 characters.')
    ])
    
    mobile_number = StringField('Mobile Number', validators=[
        DataRequired(message='Mobile number is required.')
    ])
    
    email = StringField('Email Address', validators=[
        DataRequired(message='Email Address is required.'),
        Email(message='Please provide a valid email format.')
    ])
    
    event_name = SelectField('Event Selection', choices=EVENT_CHOICES, validators=[
        DataRequired(message='Please select a technical event.')
    ])
    
    amount_paid = DecimalField('Amount Paid', places=2, validators=[
        DataRequired(message='Payment Amount is required.')
    ])
    
    payment_method = SelectField('Payment Method', choices=PAYMENT_CHOICES, validators=[
        DataRequired(message='Please select a payment method.')
    ])
    
    transaction_id = StringField('Transaction ID', validators=[
        DataRequired(message='Transaction Reference ID is required.'),
        Length(max=100, message='Transaction ID must not exceed 100 characters.')
    ])
    
    payment_screenshot = FileField('Payment Screenshot', validators=[
        FileRequired(message='Payment Receipt is required.'),
        FileAllowed(['jpg', 'jpeg', 'png', 'pdf'], message='Receipt must be in JPG, JPEG, PNG, or PDF format.')
    ])
    
    terms_accepted = BooleanField('Terms and Conditions', validators=[
        DataRequired(message='You must accept the terms and conditions to register.')
    ])

    # Custom Validators
    def validate_mobile_number(self, field):
        # Remove non-digits
        digits = re.sub(r'\D', '', field.data)
        if len(digits) != 10:
            raise ValidationError('Mobile number must contain exactly 10 digits.')

    def validate_student_photo(self, field):
        if field.data:
            # Check size in bytes (2 MB limit)
            field.data.seek(0, 2)
            size = field.data.tell()
            field.data.seek(0)
            if size > 2 * 1024 * 1024:
                raise ValidationError('Student Photo size must not exceed 2 MB.')

    def validate_payment_screenshot(self, field):
        if field.data:
            # Check size in bytes (5 MB limit)
            field.data.seek(0, 2)
            size = field.data.tell()
            field.data.seek(0)
            if size > 5 * 1024 * 1024:
                raise ValidationError('Payment Screenshot size must not exceed 5 MB.')


class LoginForm(FlaskForm):
    """
    Form class representing Admin Authentication logic.
    """
    username = StringField('Username', validators=[
        DataRequired(message='Admin Username is required.'),
        Length(max=50)
    ])
    password = PasswordField('Password', validators=[
        DataRequired(message='Admin Password is required.')
    ])
