from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()

class Admin(UserMixin, db.Model):
    """
    Admin model for authentication inside the Flask-Login session framework.
    """
    __tablename__ = 'admins'
    
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Registration(db.Model):
    """
    Registration model representing student event registrations matching the MySQL schema.
    """
    __tablename__ = 'registrations'

    registration_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    student_name = db.Column(db.String(100), nullable=False)
    student_photo = db.Column(db.String(255), nullable=False)  # Path to saved student image
    year = db.Column(db.String(20), nullable=False)
    department = db.Column(db.String(100), nullable=False)
    college_name = db.Column(db.String(150), nullable=False)
    register_number = db.Column(db.String(50), unique=True, nullable=False)
    mobile_number = db.Column(db.String(15), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    event_name = db.Column(db.String(100), nullable=False)
    amount_paid = db.Column(db.Numeric(10, 2), nullable=False)
    payment_method = db.Column(db.String(50), nullable=False)
    transaction_id = db.Column(db.String(100), nullable=False)
    payment_screenshot = db.Column(db.String(255), nullable=False)  # Path to saved screenshot/receipt
    registration_date = db.Column(db.DateTime, default=datetime.utcnow)

    def to_dict(self):
        """
        Converts SQLAlchemy model instance to dictionary representation.
        """
        return {
            'registration_id': self.registration_id,
            'student_name': self.student_name,
            'student_photo': self.student_photo,
            'year': self.year,
            'department': self.department,
            'college_name': self.college_name,
            'register_number': self.register_number,
            'mobile_number': self.mobile_number,
            'email': self.email,
            'event_name': self.event_name,
            'amount_paid': float(self.amount_paid),
            'payment_method': self.payment_method,
            'transaction_id': self.transaction_id,
            'payment_screenshot': self.payment_screenshot,
            'registration_date': self.registration_date.isoformat()
        }
