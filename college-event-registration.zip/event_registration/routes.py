from flask import Blueprint, render_name, render_template, redirect, url_for, flash, request, send_from_directory, Response, current_app
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.utils import secure_filename
from models import db, Registration, Admin
from forms import RegistrationForm, LoginForm
import os
import csv
import io
from decimal import Decimal

# Initialize blueprint
main_bp = Blueprint('main', __name__)

def allowed_file(filename, allowed_extensions):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in [ext.replace('.', '') for ext in allowed_extensions]

@main_bp.route('/')
def index():
    """
    Renders the beautiful responsive homepage featuring a countdown timer, highlights, and banners.
    """
    return render_template('index.html')


@main_bp.route('/register', methods=['GET', 'POST'])
def register():
    """
    Handles Student Event Registrations with strict WTForms and server validations.
    """
    form = RegistrationForm()
    
    # Pre-populate fee details on POST/validation if event is selected
    if request.method == 'POST':
        # Retrieve original fee to prevent manual form alteration by the user
        event_fees = {
            'WebCraft (Web Design & Development)': 150.00,
            'CodeForge (Speed Competitive Coding)': 200.00,
            'TechQuiz (General & IT Quiz)': 100.00,
            'Paper Presentation (Research Paper)': 250.00,
            'UI/UX Odyssey (Interface Design)': 150.00,
            'RoboWars (Sumo Robotics)': 300.00
        }
        selected_event = request.form.get('event_name')
        if selected_event in event_fees:
            form.amount_paid.data = Decimal(event_fees[selected_event])

    if form.validate_on_submit():
        # Double check Register Number uniqueness
        existing = Registration.query.filter_by(register_number=form.register_number.data.strip()).first()
        if existing:
            form.register_number.errors.append('This Register Number has already registered.')
            return render_template('register.html', form=form)

        # Handle Student Photo Upload
        photo_file = form.student_photo.data
        photo_ext = os.path.splitext(photo_file.filename)[1].lower()
        photo_filename = f"photo_{secure_filename(form.register_number.data)}{photo_ext}"
        photo_save_path = os.path.join(current_app.config['STUDENT_UPLOAD_SUBFOLDER'], photo_filename)
        photo_file.save(photo_save_path)
        
        # Handle Payment Screenshot Upload
        screenshot_file = form.payment_screenshot.data
        screenshot_ext = os.path.splitext(screenshot_file.filename)[1].lower()
        screenshot_filename = f"payment_{secure_filename(form.register_number.data)}{screenshot_ext}"
        screenshot_save_path = os.path.join(current_app.config['PAYMENT_UPLOAD_SUBFOLDER'], screenshot_filename)
        screenshot_file.save(screenshot_save_path)

        # Build database record
        relative_photo = f"/uploads/students/{photo_filename}"
        relative_screenshot = f"/uploads/payments/{screenshot_filename}"

        new_reg = Registration(
            student_name=form.student_name.data.strip(),
            student_photo=relative_photo,
            year=form.year.data,
            department=form.department.data,
            college_name=form.college_name.data.strip(),
            register_number=form.register_number.data.strip(),
            mobile_number=form.mobile_number.data.strip(),
            email=form.email.data.strip(),
            event_name=form.event_name.data,
            amount_paid=form.amount_paid.data,
            payment_method=form.payment_method.data,
            transaction_id=form.transaction_id.data.strip(),
            payment_screenshot=relative_screenshot
        )

        try:
            db.session.add(new_reg)
            db.session.commit()
            return render_template('success.html', reg_id=new_reg.registration_id)
        except Exception as e:
            db.session.rollback()
            # Clean physical files on DB fail
            if os.path.exists(photo_save_path): os.remove(photo_save_path)
            if os.path.exists(screenshot_save_path): os.remove(screenshot_save_path)
            flash('Database save error. Please try again later.', 'danger')

    return render_template('register.html', form=form)


@main_bp.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    """
    Authenticates Admin users using Flask-Login and secure hashes.
    """
    if current_user.is_authenticated:
        return redirect(url_for('main.admin_dashboard'))
        
    form = LoginForm()
    if form.validate_on_submit():
        admin = Admin.query.filter_by(username=form.username.data.strip()).first()
        if admin and admin.check_password(form.password.data.strip()):
            login_user(admin)
            flash('Signed in successfully.', 'success')
            return redirect(url_for('main.admin_dashboard'))
        else:
            flash('Invalid username or password credentials.', 'danger')

    return render_template('admin_login.html', form=form)


@main_bp.route('/admin/logout')
@login_required
def admin_logout():
    """
    Gracefully logs the admin user out.
    """
    logout_user()
    flash('Signed out successfully.', 'info')
    return redirect(url_for('main.index'))


@main_bp.route('/admin/dashboard')
@login_required
def admin_dashboard():
    """
    Secures and renders the Admin control board with tables, dynamic search queries, and drop-filters.
    """
    # 1. Base Query
    query = Registration.query

    # 2. Extract Filters
    search = request.args.get('search', '')
    event_filter = request.args.get('event', '')
    college_filter = request.args.get('college', '')
    dept_filter = request.args.get('department', '')
    year_filter = request.args.get('year', '')

    # Apply Search (Register Number, Student Name, College Name)
    if search:
        query = query.filter(
            Registration.student_name.ilike(f'%{search}%') |
            Registration.register_number.ilike(f'%{search}%') |
            Registration.college_name.ilike(f'%{search}%')
        )

    # Apply dropdown filters
    if event_filter:
        query = query.filter(Registration.event_name == event_filter)
    if college_filter:
        query = query.filter(Registration.college_name == college_filter)
    if dept_filter:
        query = query.filter(Registration.department == dept_filter)
    if year_filter:
        query = query.filter(Registration.year == year_filter)

    # Order newest first
    registrations = query.order_by(Registration.registration_date.desc()).all()

    # Calculate statistics
    total_entries = len(registrations)
    total_collected = sum([r.amount_paid for r in registrations])

    # Extract all unique colleges from database for filter options
    all_colleges = db.session.query(Registration.college_name).distinct().all()
    colleges_list = [c[0] for c in all_colleges if c[0]]

    return render_template(
        'admin_dashboard.html',
        registrations=registrations,
        total_entries=total_entries,
        total_collected=total_collected,
        colleges_list=colleges_list,
        search=search,
        selected_event=event_filter,
        selected_college=college_filter,
        selected_dept=dept_filter,
        selected_year=year_filter
    )


@main_bp.route('/registration/edit/<int:reg_id>', methods=['GET', 'POST'])
@login_required
def edit_registration(reg_id):
    """
    Enables Admin to edit existing user records (CRUD - Update).
    """
    record = Registration.query.get_or_404(reg_id)
    
    if request.method == 'POST':
        # Retrieve values from post request
        record.student_name = request.form.get('student_name', '').strip()
        record.year = request.form.get('year', '')
        record.department = request.form.get('department', '')
        record.college_name = request.form.get('college_name', '').strip()
        record.mobile_number = request.form.get('mobile_number', '').strip()
        record.email = request.form.get('email', '').strip()
        record.event_name = request.form.get('event_name', '')
        record.payment_method = request.form.get('payment_method', '')
        record.transaction_id = request.form.get('transaction_id', '').strip()

        # Simple backend validation
        if not record.student_name or not record.college_name or not record.mobile_number or not record.email:
            flash('Please fill in all required fields.', 'danger')
            return render_template('edit_registration.html', record=record)

        try:
            db.session.commit()
            flash('Registration record updated successfully.', 'success')
            return redirect(url_for('main.admin_dashboard'))
        except Exception as e:
            db.session.rollback()
            flash('Failed to update record. Ensure register number unique.', 'danger')

    return render_template('edit_registration.html', record=record)


@main_bp.route('/registration/delete/<int:reg_id>', methods=['POST'])
@login_required
def delete_registration(reg_id):
    """
    Enables Admin to delete a registration and clean its uploads physically (CRUD - Delete).
    """
    record = Registration.query.get_or_404(reg_id)
    
    # Try to delete files physically
    try:
        photo_path = os.path.join(current_app.root_path, record.student_photo.lstrip('/'))
        screenshot_path = os.path.join(current_app.root_path, record.payment_screenshot.lstrip('/'))
        if os.path.exists(photo_path): os.remove(photo_path)
        if os.path.exists(screenshot_path): os.remove(screenshot_path)
    except Exception as e:
        print(f"Error unlinking registration documents: {e}")

    try:
        db.session.delete(record)
        db.session.commit()
        flash('Registration log and associated files deleted.', 'success')
    except Exception as e:
        db.session.rollback()
        flash('Failed to delete registration record.', 'danger')

    return redirect(url_for('main.admin_dashboard'))


@main_bp.route('/admin/export/excel')
@login_required
def export_excel():
    """
    Generates a downloadable CSV Excel-ready file containing the filtered records.
    """
    registrations = Registration.query.order_by(Registration.registration_date.desc()).all()
    
    si = io.StringIO()
    cw = csv.writer(si)
    
    # Header row
    cw.writerow([
        'ID', 'Student Name', 'Academic Year', 'Department', 'College Name', 
        'Register Number', 'Mobile Number', 'Email', 'Event Name', 
        'Amount Paid ($)', 'Payment Method', 'Transaction Reference ID', 'Registration Date'
    ])
    
    for r in registrations:
        cw.writerow([
            f"PIN{r.registration_id}",
            r.student_name,
            r.year,
            r.department,
            r.college_name,
            r.register_number,
            r.mobile_number,
            r.email,
            r.event_name,
            float(r.amount_paid),
            r.payment_method,
            r.transaction_id,
            r.registration_date.strftime('%Y-%m-%d %H:%M:%S')
        ])
    
    output = make_response(si.getvalue())
    output.headers["Content-Disposition"] = "attachment; filename=Pinnacle_Roster_Excel.csv"
    output.headers["Content-type"] = "text/csv"
    return output


@main_bp.route('/admin/export/pdf')
@login_required
def export_pdf():
    """
    Exports clean registration records in a printable grid PDF.
    """
    registrations = Registration.query.order_by(Registration.registration_date.desc()).all()
    
    # We can create a lightweight printable HTML page for PDF generation or simple printing layout.
    # Standard Flask developers use reportlab or print stylesheets. Let's provide a beautiful print view!
    html = """
    <html>
    <head>
        <title>Pinnacle 2026 - Roster Report</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 30px; font-size: 11px; color: #333; }
            h1 { font-size: 18px; margin-bottom: 5px; color: #1e3a8a; }
            p { margin: 2px 0; color: #666; }
            table { width: 100%; border-collapse: collapse; margin-top: 20px; }
            th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
            th { background-color: #1e3a8a; color: white; font-weight: bold; }
            tr:nth-child(even) { background-color: #f8fafc; }
            .meta { margin-bottom: 25px; padding-bottom: 15px; border-b: 2px solid #1e3a8a; }
        </style>
    </head>
    <body onload="window.print()">
        <div class="meta">
            <h1>Apex Institute of Technology - Pinnacle 2026</h1>
            <p>Official Event Registration Roster Report</p>
            <p>Generated: Today | Total Registrations: """ + str(len(registrations)) + """</p>
        </div>
        <table>
            <thead>
                <tr>
                    <th>Reg ID</th>
                    <th>Student Name</th>
                    <th>College Name</th>
                    <th>Department</th>
                    <th>Register Number</th>
                    <th>Event Domain</th>
                    <th>Amount Paid</th>
                    <th>Method</th>
                    <th>Tx ID</th>
                </tr>
            </thead>
            <tbody>
    """
    for r in registrations:
        html += f"""
                <tr>
                    <td>PIN{r.registration_id}</td>
                    <td><b>{r.student_name}</b></td>
                    <td>{r.college_name}</td>
                    <td>{r.department.split(' (')[0]}</td>
                    <td>{r.register_number}</td>
                    <td>{r.event_name.split(' (')[0]}</td>
                    <td>${r.amount_paid:.2f}</td>
                    <td>{r.payment_method}</td>
                    <td>{r.transaction_id}</td>
                </tr>
        """
    html += """
            </tbody>
        </table>
    </body>
    </html>
    """
    
    return Response(html, mimetype="text/html")


# Support direct rendering helper
def make_response(body):
    return Response(body, mimetype="text/csv")
